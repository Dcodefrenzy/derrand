
<?php

?>

<div class="col-md-4 products-left">
  <div class="categories">
    <h2>Categories</h2>
    <ul class="cate">
      <?php fetchSideCategory($conn); ?>
    

    </ul>
  </div>
</div>
