<section class="foot">
  <div>
    <p>&copy; 2016;
  </div>
</section>
</body>
</html>
